export interface PdfFile {
  id: number;
  name: string;
  url: string;
  coverUrl: string;
}
